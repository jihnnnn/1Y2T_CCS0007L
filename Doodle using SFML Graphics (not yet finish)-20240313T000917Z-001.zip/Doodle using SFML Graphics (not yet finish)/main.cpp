#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp> 
#include <time.h>
using namespace sf;

struct Point
{
    int x, y;
};

class DoodleGame
{
private:
    RenderWindow app;
    Texture backgroundTexture, platformTexture, characterTexture;
    Sprite backgroundSprite, platformSprite, characterSprite;
    Point platforms[7];
    bool gameStarted;
    int x, y, h, score;
    float dy;
    const float initialJumpHeight;
    float jumpHeight;
    SoundBuffer jumpBuffer; 
    Sound jumpSound;        
    Music backgroundMusic;  

public:
    DoodleGame() : app(VideoMode(400, 533), "Doodle Game"), initialJumpHeight(-9.0f), score(0)
    {
        app.setFramerateLimit(60);

        backgroundTexture.loadFromFile("background.png");
        platformTexture.loadFromFile("platform.png");
        characterTexture.loadFromFile("character.png");

        backgroundSprite.setTexture(backgroundTexture);
        platformSprite.setTexture(platformTexture);
        characterSprite.setTexture(characterTexture);

        gameStarted = false;
        x = 100;
        y = 100;
        h = 200;
        dy = 0;
        jumpHeight = initialJumpHeight;

        
        jumpBuffer.loadFromFile("Jump.wav");
        jumpSound.setBuffer(jumpBuffer);

        
        if (backgroundMusic.openFromFile("Bg.wav"))
        {
            backgroundMusic.setLoop(true);
            backgroundMusic.play();
        }
    }

    void resetGame()
    {
        for (int i = 0; i < 6; i += 2)
        {
            platforms[i].x = rand() % 300;
            platforms[i].y = rand() % 433;

            platforms[i + 1].x = platforms[i].x + 200;
            platforms[i + 1].y = platforms[i].y - rand() % 40 - 100;
        }

        platforms[6].x = 0;
        platforms[6].y = 533;
    }

    void run()
    {
        while (app.isOpen())
        {
            Event e;
            while (app.pollEvent(e))
            {
                if (e.type == Event::Closed)
                    app.close();
            }

            if (!gameStarted)
            {
                resetGame();
                gameStarted = true;
                x = 100;
                y = h;
            }

            if (Keyboard::isKeyPressed(Keyboard::Right))
                x += 4;
            if (Keyboard::isKeyPressed(Keyboard::Left))
                x -= 4;

            if (x < 0)
                x = 0;
            if (x > app.getSize().x - 50)
                x = app.getSize().x - 50;

            y += dy;

            for (int i = 0; i < 7; i++)
            {
                platforms[i].y -= dy;
                if (platforms[i].y > 533)
                {
                    platforms[i].y = 1;
                    platforms[i].x = rand() % 300;
                }
            }

            dy += 0.2;

            if (y < h)
            {
                for (int i = 0; i < 7; i++)
                {
                    y = h;
                    platforms[i].y = platforms[i].y - dy;
                    if (platforms[i].y > 533)
                    {
                        platforms[i].y = 1;
                        platforms[i].x = rand() % 300;
                    }
                }
            }

            if (y > 500)
            {
                gameStarted = false;
                resetGame();
                y = h;
                dy = initialJumpHeight;
                jumpHeight = initialJumpHeight;
                score = static_cast<int>(y - h); 
            }

            for (int i = 0; i < 7; i++)
            {
                if ((x + 50 > platforms[i].x) && (x + 20 < platforms[i].x + 68) &&
                    (y + 70 > platforms[i].y) && (y + 70 < platforms[i].y + 14) && (dy > 0))
                {
                    dy = initialJumpHeight;
                    jumpSound.play(); 
                }
            }

            app.clear();
            app.draw(backgroundSprite);
            for (int i = 0; i < 7; i++)
            {
                platformSprite.setPosition(platforms[i].x, platforms[i].y);
                app.draw(platformSprite);
            }
            characterSprite.setPosition(x, y);
            app.draw(characterSprite);

            app.display();
        }
    }
};

int main()
{
    srand(time(0));
    DoodleGame game;
    game.run();
    return 0;
}

